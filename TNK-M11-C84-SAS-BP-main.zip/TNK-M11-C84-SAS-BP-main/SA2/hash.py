# Import hashlib library


def generateHash(inputString):

    # Create a hash object using SHA-256 algorithm

    # Convert the input string to bytes and update the hash object
    
    # Get the hexadecimal representation of the hash in hashValue variable
    
    
    return hashValue


inputString = "Hello, Conver me into a hash."
print("Input String:", inputString)
hashValue = generateHash(inputString)
print("Hash value:", hashValue)
