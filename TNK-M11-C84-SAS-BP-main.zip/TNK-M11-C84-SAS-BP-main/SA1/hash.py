# Define function named generatehash with parameter inputString

    # Initialize the hash value to 0

    # Iterate over each character in the input string

        # Update the hash value by adding the ASCII value of the character

    # Return the hash value    


inputString = "Hello, Conver me into a hash."

print("Input String:", inputString)
# Call generate Hash() function with 'inputString' and store the results in 'hashValue' variable


# Print the hash value 


